myApp.controller("MyController", function($scope, $http)
            {
              $scope.submit = function(){
              
                var data = {
                  'username' : $scope.username,
                  'password' : $scope.password,
                };
                console.log(data);
          
                var config = { headers : { 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;' }};

                $http({
                    method : "POST",
                    url : "Server\server.js\login",
                    data : data
                })
                .success(function (data, status, headers, config) {
                    console.log("data returned " ,data);
                    if (data == "success") {
                      window.location.href = "/";
                    }else {
                      alert(data)
                    }
                })
                .error(function (data, status, header, config) {
                    $scope.ResponseDetails = "Data: " + data +
                        "<hr />status: " + status +
                        "<hr />headers: " + header +
                        "<hr />config: " + config;
                });


              }
            });